Installation instructions:

Download or git-clone onto your favorite webserver. That's it!

Questions? s.r.mcgann[at]hotmail.com 


